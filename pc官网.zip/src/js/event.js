/**
 * event.js
 * 自定义事件对象
 * 用于简单的兄弟组件间通讯
 */

import Vue from 'vue'

export default new Vue()
